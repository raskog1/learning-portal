import React from "react";

function Staff() {
  return <h1>Staff</h1>;
}

export default Staff;
